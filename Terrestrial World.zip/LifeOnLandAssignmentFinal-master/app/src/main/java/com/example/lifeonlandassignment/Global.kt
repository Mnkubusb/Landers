package com.example.lifeonlandassignment

object Global {
    var loginUser: String = ""
    var donationEventId: Int = 0
    var editEventId: Int = 0
    var happenEventId: Int = 0
    var deleteNoti: Int = 0
}